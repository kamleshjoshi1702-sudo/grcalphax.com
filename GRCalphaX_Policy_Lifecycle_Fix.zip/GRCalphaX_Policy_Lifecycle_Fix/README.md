# GRCalphaX – Policy Lifecycle Detection Fix

## What changed

- The policy library now calculates lifecycle status from policy version, uploaded document version, document effective/approval date, and the next review date.
- An uploaded version older than the policy record's current version is marked **Outdated**.
- A document effective/approval date earlier than the approved baseline is marked **Outdated** when an approved baseline date exists.
- A past-due review date is marked **Outdated**; a review due within 30 days is shown as **Review Due Soon**.
- Legacy uploaded attachments without both version and document date are marked **Potentially Outdated** / verification required, rather than silently considered current.
- The dashboard banner, dashboard priorities, policy table, and policy details use the same lifecycle calculation.
- The existing-policy upload form accepts document version and effective/approval date. It suggests a version from filenames such as `v1.2` and a date from filenames such as `2025-10-31`.
- When a verified current/newer document is uploaded, earlier attachments are moved into version history so superseded files do not continue triggering an outdated warning.
- Policy changes broadcast to other tabs using BroadcastChannel and localStorage signals; the dashboard and policy page refresh on updates, focus, and tab visibility.

## Validation performed

- JavaScript syntax validation: passed (`node --check`).
- Lifecycle logic tests: passed for older version, missing metadata, overdue review, verified current version, and review due soon.

## Important limitations

This is still the browser-local GRCalphaX prototype. Policy records are stored in browser localStorage / IndexedDB. Live updates apply to tabs using the same browser profile and same origin. This does not synchronise different devices or users through a central server; that requires shared backend storage and server-side event delivery.

The standalone HTML build does not extract policy text from inside PDF/Word documents. It compares the version and effective/approval date supplied in the upload form, plus review dates. Filename hints are best-effort only. For reliable automated content extraction and legal/regulatory change analysis, integrate server-side PDF/DOCX parsing and an approved policy-review workflow.

For an attachment uploaded before this fix, the existing file remains linked to its policy record. Since the prior upload flow did not record the document's internal version/date, it will appear as **Potentially Outdated** until those details are verified or a versioned replacement is uploaded.
