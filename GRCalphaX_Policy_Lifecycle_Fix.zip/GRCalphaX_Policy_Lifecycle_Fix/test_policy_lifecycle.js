const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync('/mnt/data/GRCalphaX_Complete_Updated_Source.html','utf8');
const start=source.indexOf('function gaxPolicyIsoDate');
const end=source.indexOf('function policyRecordSearchText',start);
if(start<0||end<0) throw new Error('Lifecycle helper block not found');
let helper=source.slice(start,end);
const alertStart=source.indexOf('function gaxPolicyReviewAlertHtml(records)');
const alertEnd=source.indexOf('\n}\n\n// ---------- Audit Management:',alertStart)+2;
const alertFn=source.slice(alertStart,alertEnd);
const ctx={console,Date,Set,Math,escapeHtml:x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))};
vm.createContext(ctx); vm.runInContext(helper+'\n'+alertFn,ctx);
const now=new Date('2026-11-25T12:00:00');
const cases=[
 ['older version', {id:'p1',name:'Access Control Policy',status:'Active',version:'2.0',approvedVersion:'2.0',approvedDate:'2026-01-01',attachments:[{id:'a1',policyVersion:'1.0',documentDate:'2025-10-01'}]}, 'Outdated'],
 ['missing metadata', {id:'p2',name:'Incident Response Policy',status:'Under Review',version:'1.0',attachments:[{id:'a2',name:'IR-policy.pdf'}]}, 'Potentially Outdated'],
 ['review overdue', {id:'p3',name:'Risk Policy',status:'Active',version:'1.0',reviewDate:'2026-10-01',attachments:[]}, 'Outdated'],
 ['verified current version', {id:'p4',name:'Asset Policy',status:'Under Review',version:'2.0',approvedVersion:'2.0',approvedDate:'2026-01-01',attachments:[{id:'a4',policyVersion:'2.0',documentDate:'2026-01-01'}]}, 'Under Review'],
 ['review due soon', {id:'p5',name:'Supplier Policy',status:'Active',version:'1.0',reviewDate:'2026-12-05',attachments:[]}, 'Review Due Soon']
];
let failed=0;
for(const [name,rec,expected] of cases){const got=ctx.gaxPolicyLifecycle(rec,now).status;const ok=got===expected;console.log(`${ok?'PASS':'FAIL'} ${name}: ${got} (expected ${expected})`);if(!ok)failed++;}
const alert=ctx.gaxPolicyReviewAlertHtml(cases.map(x=>x[1]));
console.log('dashboard alert contains outdated:',/outdated/i.test(alert));
console.log('dashboard alert contains verification:',/verification/i.test(alert));
if(failed||!(/outdated/i.test(alert))||!(/verification/i.test(alert)))process.exit(1);
